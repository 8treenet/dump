// 简单的测试脚本，直接测试消息队列功能

// 模拟ChatType枚举
const ChatType = {
  DM: 'dm',
  Group: 'group'
};

// 消息队列类型定义
class MessageQueueItem {
  constructor(body, api, receivedAtMs = Date.now()) {
    this.body = body;
    this.api = api;
    this.receivedAtMs = receivedAtMs;
  }
}

// 会话隔离的消息队列
class SessionIsolatedQueue {
  constructor() {
    this.queues = new Map();
    this.processing = new Map();
    this.debounceBuffer = new Map();
    this.textFragmentBuffer = new Map();
    this.processMessage = this.processMessage.bind(this);
  }

  // 获取会话键
  getSessionKey(body) {
    const chatType = body.chatType || ChatType.DM;
    return chatType === ChatType.DM 
      ? `loop:${body.accountId}:${body.from}` 
      : `loop:${body.accountId}:group:${body.gid || body.to}`;
  }

  // 去抖动处理
  handleDebounce(entry) {
    const key = this.getSessionKey(entry.body);
    const existing = this.debounceBuffer.get(key);

    if (existing) {
      clearTimeout(existing.timer);
    }

    const timer = setTimeout(async () => {
      this.debounceBuffer.delete(key);
      await this.enqueueInternal({
        ...entry,
        body: entry.body,
      });
    }, 100); // 100ms去抖动

    this.debounceBuffer.set(key, {
      ...entry,
      timer,
    });
  }

  // 文本片段处理
  handleTextFragment(item) {
    const { body } = item;
    const text = body.text || "";
    const isCommandLike = text.trim().startsWith("/");

    if (!text || isCommandLike) {
      return false;
    }

    const key = this.getSessionKey(body);
    const existing = this.textFragmentBuffer.get(key);

    if (existing) {
      const last = existing.messages.at(-1);
      const lastReceivedAtMs = last?.receivedAtMs ?? item.receivedAtMs;
      const timeGapMs = item.receivedAtMs - lastReceivedAtMs;

      const canAppend = timeGapMs >= 0 && timeGapMs <= 1500; // 1500ms超时

      if (canAppend) {
        const currentTotalChars = existing.messages.reduce(
          (sum, m) => sum + (m.body.text?.length ?? 0),
          0
        );
        const nextTotalChars = currentTotalChars + text.length;

        if (
          existing.messages.length + 1 <= 12 && // 最大12个片段
          nextTotalChars <= 50000 // 最大50,000字符
        ) {
          existing.messages.push({
            body: { ...body, text: text },
            api: item.api,
            receivedAtMs: item.receivedAtMs,
          });
          this.scheduleTextFragmentFlush(existing);
          return true;
        }
      }

      // 不能追加，先刷新现有条目
      this.flushTextFragment(existing);
    }

    const shouldStart = text.length >= 4000; // 长文本开始合并
    if (shouldStart) {
      const entry = {
        key,
        messages: [{ body: { ...body, text }, api: item.api, receivedAtMs: item.receivedAtMs }],
        timer: setTimeout(() => {}, 1500),
      };
      this.textFragmentBuffer.set(key, entry);
      this.scheduleTextFragmentFlush(entry);
      return true;
    }

    return false;
  }

  // 调度文本片段刷新
  scheduleTextFragmentFlush(entry) {
    clearTimeout(entry.timer);
    entry.timer = setTimeout(() => {
      this.flushTextFragment(entry);
    }, 1500);
  }

  // 刷新文本片段
  async flushTextFragment(entry) {
    this.textFragmentBuffer.delete(entry.key);
    
    if (entry.messages.length === 0) {
      return;
    }

    // 合并文本
    const combinedText = entry.messages
      .map((m) => m.body.text || "")
      .filter(Boolean)
      .join("");

    if (!combinedText.trim()) {
      return;
    }

    // 使用第一个消息作为基础，合并文本
    const first = entry.messages[0];
    const mergedBody = {
      ...first.body,
      text: combinedText,
      id: entry.messages.at(-1)?.body.id || first.body.id,
    };

    await this.enqueueInternal({
      body: mergedBody,
      api: first.api,
      receivedAtMs: entry.messages.at(-1)?.receivedAtMs || first.receivedAtMs,
    });
  }

  // 内部入队
  async enqueueInternal(item) {
    const key = this.getSessionKey(item.body);
    const queue = this.queues.get(key) || [];
    queue.push(item);
    this.queues.set(key, queue);

    if (!this.processing.get(key)) {
      this.processNext(key);
    }
  }

  // 入队
  async enqueue(body, api) {
    const receivedAtMs = Date.now();
    const item = new MessageQueueItem(body, api, receivedAtMs);

    // 先尝试文本片段合并
    if (this.handleTextFragment(item)) {
      return;
    }

    // 再尝试去抖动
    this.handleDebounce({ body, api, receivedAtMs });
  }

  // 处理消息
  async processMessage(body, api) {
    console.log(`[${new Date().toLocaleTimeString()}] Processing message from ${body.from}: ${body.text.substring(0, 50)}${body.text.length > 50 ? '...' : ''}`);
    // 模拟AI处理延迟
    await new Promise(resolve => setTimeout(resolve, 100));
  }

  // 处理下一个消息
  async processNext(key) {
    const queue = this.queues.get(key) || [];
    
    if (queue.length === 0) {
      this.processing.set(key, false);
      return;
    }

    this.processing.set(key, true);
    const item = queue.shift();

    if (item) {
      try {
        await this.processMessage(item.body, item.api);
      } catch (error) {
        console.error(`Error processing message for session ${key}:`, error);
      } finally {
        this.processNext(key);
      }
    }
  }
}

// 模拟API
class MockApi {
  config = {};
  runtime = {
    channel: {
      reply: {
        finalizeInboundContext: () => ({}),
        dispatchReplyWithBufferedBlockDispatcher: async ({ dispatcherOptions }) => {
          await dispatcherOptions.deliver({ text: 'AI response' }, { kind: 'final' });
        }
      }
    }
  };
}

// 测试函数
async function runTests() {
  console.log('=== 开始测试消息队列 ===\n');
  
  const queue = new SessionIsolatedQueue();
  const api = new MockApi();
  
  // 测试1: 会话隔离
  console.log('测试1: 会话隔离');
  console.log('发送不同用户的消息...');
  
  const messages = [
    { from: 'user1', text: 'Hello user1', accountId: 'test', to: 'bot', chatType: ChatType.DM },
    { from: 'user2', text: 'Hello user2', accountId: 'test', to: 'bot', chatType: ChatType.DM },
    { from: 'user1', text: 'How are you?', accountId: 'test', to: 'bot', chatType: ChatType.DM }
  ];
  
  for (const msg of messages) {
    await queue.enqueue(msg, api);
    await new Promise(resolve => setTimeout(resolve, 50));
  }
  
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // 测试2: 去抖动
  console.log('\n测试2: 去抖动');
  console.log('短时间内发送相同用户的多条消息...');
  
  for (let i = 0; i < 3; i++) {
    await queue.enqueue({
      from: 'debounce_user',
      text: `Message ${i + 1}`,
      accountId: 'test',
      to: 'bot',
      chatType: ChatType.DM
    }, api);
    await new Promise(resolve => setTimeout(resolve, 30)); // 30ms间隔
  }
  
  await new Promise(resolve => setTimeout(resolve, 200));
  
  // 测试3: 文本片段合并
  console.log('\n测试3: 文本片段合并');
  console.log('发送长文本片段...');
  
  const longText1 = 'This is a very long text that should be merged. '.repeat(20);
  const longText2 = 'This is the continuation of the long text. '.repeat(20);
  
  await queue.enqueue({
    from: 'fragment_user',
    text: longText1,
    accountId: 'test',
    to: 'bot',
    chatType: ChatType.DM
  }, api);
  
  await new Promise(resolve => setTimeout(resolve, 100));
  
  await queue.enqueue({
    from: 'fragment_user',
    text: longText2,
    accountId: 'test',
    to: 'bot',
    chatType: ChatType.DM
  }, api);
  
  await new Promise(resolve => setTimeout(resolve, 2000));
  
  console.log('\n=== 所有测试完成 ===');
}

// 运行测试
runTests().catch(console.error);
