// 测试AI超时功能的脚本

// 模拟OpenClawPluginApi
class MockOpenClawPluginApi {
  config = {};
  runtime = {
    channel: {
      reply: {
        finalizeInboundContext: () => ({}),
        dispatchReplyWithBufferedBlockDispatcher: async ({ dispatcherOptions }) => {
          // 模拟AI处理延迟超过超时时间
          await new Promise(resolve => setTimeout(resolve, 2000)); // 2秒延迟
          await dispatcherOptions.deliver({ text: 'AI response' }, { kind: 'final' });
        }
      }
    }
  };
}

// 模拟sendLoopMessage
async function mockSendLoopMessage(payload, to, chatType, gid) {
  console.log(`[SendMessage] To: ${to}, Text: ${payload.text}`);
}

// 模拟processMedia
async function mockProcessMedia(body) {
  return { mediaPath: undefined, mediaType: undefined };
}

// 模拟buildMessageContext
function mockBuildMessageContext(body, api, mediaPath, mediaType) {
  return {
    SessionKey: `loop:${body.accountId}:${body.from}`,
    InboundText: body.text,
    InboundAttachments: [],
    Channel: 'loop',
    AccountId: body.accountId,
    ChatType: body.chatType || 'dm',
    From: body.from,
    To: body.to,
    ThreadId: body.gid,
    Extras: {}
  };
}

// 模拟超时处理的processMessage函数
async function mockProcessMessage(body, api) {
  console.log("[LoopChannel] Processing message:", body);

  try {
    // 处理媒体文件
    const { mediaPath, mediaType } = await mockProcessMedia(body);

    // 构建消息上下文
    const messageContext = mockBuildMessageContext(body, api, mediaPath, mediaType);

    // 设置超时时间（1秒）
    const LOOP_AI_PROCESSING_TIMEOUT_MS = 1000;

    // 创建超时Promise
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => {
        reject(new Error(`AI processing timeout after ${LOOP_AI_PROCESSING_TIMEOUT_MS / 1000}s`));
      }, LOOP_AI_PROCESSING_TIMEOUT_MS);
    });

    // 发送给OpenClaw AI处理（带超时）
    await Promise.race([
      api.runtime.channel.reply.dispatchReplyWithBufferedBlockDispatcher({
        ctx: messageContext,
        cfg: api.config,
        dispatcherOptions: {
          deliver: async (payload) => {
            console.log("[LoopChannel] AI Reply received:", payload);
            await mockSendLoopMessage(payload, body.from, body.chatType || 'dm', body.gid);
          },
        },
      }),
      timeoutPromise
    ]);
  } catch (error) {
    console.error("[LoopChannel] Error processing message:", error);
    
    // 如果是超时错误，发送超时提示
    if (error.message.includes("AI processing timeout")) {
      try {
        await mockSendLoopMessage(
          { text: `AI处理超时，请稍后再试（超时时间：1秒）` },
          body.from,
          body.chatType || 'dm',
          body.gid
        );
      } catch (sendError) {
        console.error("[LoopChannel] Failed to send timeout message:", sendError);
      }
    }
    
    throw error;
  }
}

// 运行测试
async function runTimeoutTest() {
  console.log('=== 测试AI超时功能 ===\n');
  
  const api = new MockOpenClawPluginApi();
  
  const testMessage = {
    from: 'test_user',
    text: 'This is a test message that should timeout',
    accountId: 'test',
    to: 'bot',
    chatType: 'dm'
  };
  
  console.log('发送测试消息...');
  
  try {
    await mockProcessMessage(testMessage, api);
    console.log('❌ 测试失败：应该超时但没有超时');
  } catch (error) {
    if (error.message.includes("AI processing timeout")) {
      console.log('✅ 测试成功：AI处理超时，超时提示已发送');
    } else {
      console.log(`❌ 测试失败：发生其他错误: ${error.message}`);
    }
  }
  
  console.log('\n=== 测试完成 ===');
}

// 运行测试
runTimeoutTest().catch(console.error);
