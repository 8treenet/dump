// 简单的JavaScript测试文件
const { SessionIsolatedQueue } = require('../dist/webhook.js');
const { ChatType } = require('../dist/tools.js');

// 模拟 OpenClawPluginApi
class MockOpenClawPluginApi {
  config = {};
  runtime = {
    channel: {
      reply: {
        finalizeInboundContext: () => ({}),
        dispatchReplyWithBufferedBlockDispatcher: async ({ dispatcherOptions }) => {
          await dispatcherOptions.deliver({ text: 'AI response' }, { kind: 'final' });
        }
      }
    }
  };
}

// 模拟处理函数
async function mockProcessMessage(body, api) {
  console.log(`Processing message from ${body.from}: ${body.text}`);
  // 模拟AI处理延迟
  await new Promise(resolve => setTimeout(resolve, 100));
}

// 测试会话隔离
async function testSessionIsolation() {
  console.log('\n=== 测试会话隔离 ===');
  
  const queue = new SessionIsolatedQueue();
  const api = new MockOpenClawPluginApi();
  
  const messages = [
    {
      from: 'user1',
      text: 'Hello from user 1',
      accountId: 'test',
      to: 'bot',
      chatType: ChatType.DM
    },
    {
      from: 'user2',
      text: 'Hello from user 2',
      accountId: 'test',
      to: 'bot',
      chatType: ChatType.DM
    },
    {
      from: 'user1',
      text: 'Second message from user 1',
      accountId: 'test',
      to: 'bot',
      chatType: ChatType.DM
    }
  ];

  console.log('发送消息...');
  const startTime = Date.now();
  
  for (const msg of messages) {
    await queue.enqueue(msg, api);
    await new Promise(resolve => setTimeout(resolve, 50));
  }

  // 等待所有消息处理完成
  await new Promise(resolve => setTimeout(resolve, 500));
  
  console.log(`总处理时间: ${Date.now() - startTime}ms`);
  console.log('会话隔离测试完成');
}

// 测试去抖动
async function testDebounce() {
  console.log('\n=== 测试去抖动 ===');
  
  const queue = new SessionIsolatedQueue();
  const api = new MockOpenClawPluginApi();
  
  const startTime = Date.now();
  
  // 短时间内发送相同用户的多条消息
  for (let i = 0; i < 5; i++) {
    await queue.enqueue({
      from: 'debounce_user',
      text: `Message ${i + 1}`,
      accountId: 'test',
      to: 'bot',
      chatType: ChatType.DM
    }, api);
    await new Promise(resolve => setTimeout(resolve, 20)); // 20ms间隔，触发去抖动
  }

  // 等待去抖动处理完成
  await new Promise(resolve => setTimeout(resolve, 200));
  
  console.log(`去抖动测试完成，耗时: ${Date.now() - startTime}ms`);
}

// 测试文本片段合并
async function testTextFragmentMerge() {
  console.log('\n=== 测试文本片段合并 ===');
  
  const queue = new SessionIsolatedQueue();
  const api = new MockOpenClawPluginApi();
  
  const longTextPart1 = 'This is a very long text that simulates a message being split into multiple fragments. '.repeat(50);
  const longTextPart2 = 'This is the continuation of the long text fragment. '.repeat(50);
  
  await queue.enqueue({
    from: 'fragment_user',
    text: longTextPart1,
    accountId: 'test',
    to: 'bot',
    chatType: ChatType.DM
  }, api);
  
  // 模拟分段发送
  await new Promise(resolve => setTimeout(resolve, 100));
  
  await queue.enqueue({
    from: 'fragment_user',
    text: longTextPart2,
    accountId: 'test',
    to: 'bot',
    chatType: ChatType.DM
  }, api);

  // 等待合并处理完成
  await new Promise(resolve => setTimeout(resolve, 2000));
  
  console.log('文本片段合并测试完成');
}

// 运行所有测试
async function runAllTests() {
  console.log('开始测试 SessionIsolatedQueue...');
  
  await testSessionIsolation();
  await testDebounce();
  await testTextFragmentMerge();
  
  console.log('\n=== 所有测试完成 ===');
}

// 运行测试
runAllTests().catch(console.error);
