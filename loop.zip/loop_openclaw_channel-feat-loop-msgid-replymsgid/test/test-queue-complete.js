// 完整的消息队列核心要求测试

// 模拟ChatType枚举
const ChatType = {
  DM: 'dm',
  Group: 'group'
};

// 完整的消息队列类（基于实际实现）
class CompleteSessionIsolatedQueue {
  constructor() {
    this.queues = new Map();
    this.processing = new Map();
    this.debounceBuffer = new Map();
    this.textFragmentBuffer = new Map();
    this.processedMessages = [];
    this.processOrder = [];
    this.errorCount = 0;
  }

  getSessionKey(body) {
    const chatType = body.chatType || ChatType.DM;
    return chatType === ChatType.DM 
      ? `loop:${body.accountId}:${body.from}` 
      : `loop:${body.accountId}:group:${body.gid || body.to}`;
  }

  // 去抖动处理
  handleDebounce(entry) {
    const key = this.getSessionKey(entry.body);
    const existing = this.debounceBuffer.get(key);

    if (existing) {
      clearTimeout(existing.timer);
    }

    const timer = setTimeout(async () => {
      this.debounceBuffer.delete(key);
      await this.enqueueInternal({
        ...entry,
        body: entry.body,
      });
    }, 100); // 100ms去抖动

    this.debounceBuffer.set(key, {
      ...entry,
      timer,
    });
  }

  // 文本片段处理
  handleTextFragment(item) {
    const { body } = item;
    const text = body.text || "";
    const isCommandLike = text.trim().startsWith("/");

    if (!text || isCommandLike) {
      return false;
    }

    const key = this.getSessionKey(body);
    const existing = this.textFragmentBuffer.get(key);

    if (existing) {
      const last = existing.messages.at(-1);
      const lastReceivedAtMs = last?.receivedAtMs ?? item.receivedAtMs;
      const timeGapMs = item.receivedAtMs - lastReceivedAtMs;

      const canAppend = timeGapMs >= 0 && timeGapMs <= 1500; // 1500ms超时

      if (canAppend) {
        const currentTotalChars = existing.messages.reduce(
          (sum, m) => sum + (m.body.text?.length ?? 0),
          0
        );
        const nextTotalChars = currentTotalChars + text.length;

        if (
          existing.messages.length + 1 <= 12 && // 最大12个片段
          nextTotalChars <= 50000 // 最大50,000字符
        ) {
          existing.messages.push({
            body: { ...body, text: text },
            api: item.api,
            receivedAtMs: item.receivedAtMs,
          });
          this.scheduleTextFragmentFlush(existing);
          return true;
        }
      }

      // 不能追加，先刷新现有条目
      this.flushTextFragment(existing);
    }

    const shouldStart = text.length >= 4000; // 长文本开始合并
    if (shouldStart) {
      const entry = {
        key,
        messages: [{ body: { ...body, text }, api: item.api, receivedAtMs: item.receivedAtMs }],
        timer: setTimeout(() => {}, 1500),
      };
      this.textFragmentBuffer.set(key, entry);
      this.scheduleTextFragmentFlush(entry);
      return true;
    }

    return false;
  }

  // 调度文本片段刷新
  scheduleTextFragmentFlush(entry) {
    clearTimeout(entry.timer);
    entry.timer = setTimeout(() => {
      this.flushTextFragment(entry);
    }, 1500);
  }

  // 刷新文本片段
  async flushTextFragment(entry) {
    this.textFragmentBuffer.delete(entry.key);
    
    if (entry.messages.length === 0) {
      return;
    }

    // 合并文本
    const combinedText = entry.messages
      .map((m) => m.body.text || "")
      .filter(Boolean)
      .join("");

    if (!combinedText.trim()) {
      return;
    }

    // 使用第一个消息作为基础，合并文本
    const first = entry.messages[0];
    const mergedBody = {
      ...first.body,
      text: combinedText,
      id: entry.messages.at(-1)?.body.id || first.body.id,
    };

    await this.enqueueInternal({
      body: mergedBody,
      api: first.api,
      receivedAtMs: entry.messages.at(-1)?.receivedAtMs || first.receivedAtMs,
    });
  }

  // 内部入队
  async enqueueInternal(item) {
    const key = this.getSessionKey(item.body);
    const queue = this.queues.get(key) || [];
    queue.push(item);
    this.queues.set(key, queue);

    if (!this.processing.get(key)) {
      this.processNext(key);
    }
  }

  // 入队
  async enqueue(body, api) {
    const receivedAtMs = Date.now();
    const item = { body, api, receivedAtMs };

    // 先尝试文本片段合并
    if (this.handleTextFragment(item)) {
      return;
    }

    // 再尝试去抖动
    this.handleDebounce({ body, api, receivedAtMs });
  }

  // 处理消息
  async processMessage(body, api) {
    this.processedMessages.push(body);
    this.processOrder.push({ 
      key: this.getSessionKey(body), 
      message: body.text,
      timestamp: Date.now()
    });
    
    // 模拟处理延迟
    await new Promise(resolve => setTimeout(resolve, 50));
  }

  // 处理下一个消息
  async processNext(key) {
    const queue = this.queues.get(key) || [];
    
    if (queue.length === 0) {
      this.processing.set(key, false);
      return;
    }

    this.processing.set(key, true);
    const item = queue.shift();

    if (item) {
      try {
        await this.processMessage(item.body, item.api);
      } catch (error) {
        this.errorCount++;
        console.error(`Error processing message for session ${key}:`, error);
      } finally {
        this.processNext(key);
      }
    }
  }

  // 清理资源
  cleanup() {
    // 清理过期的去抖动条目
    const now = Date.now();
    for (const [key, entry] of this.debounceBuffer.entries()) {
      if (now - entry.receivedAtMs > 200) { // 2倍去抖动时间
        clearTimeout(entry.timer);
        this.debounceBuffer.delete(key);
      }
    }

    // 清理过期的文本片段
    for (const [key, entry] of this.textFragmentBuffer.entries()) {
      if (now - entry.messages[0].receivedAtMs > 3000) { // 2倍合并超时
        clearTimeout(entry.timer);
        this.textFragmentBuffer.delete(key);
      }
    }

    // 清理空队列
    for (const [key, queue] of this.queues.entries()) {
      if (queue.length === 0) {
        this.queues.delete(key);
        this.processing.delete(key);
      }
    }
  }

  // 重置状态（用于测试）
  reset() {
    this.queues.clear();
    this.processing.clear();
    this.debounceBuffer.clear();
    this.textFragmentBuffer.clear();
    this.processedMessages = [];
    this.processOrder = [];
    this.errorCount = 0;
  }
}

// 测试用例类
class QueueRequirementsTest {
  constructor() {
    this.queue = new CompleteSessionIsolatedQueue();
    this.api = {};
  }

  // 核心要求列表
  getRequirements() {
    return [
      { id: 1, name: '会话隔离', description: '不同用户的消息可以并发处理，同一会话的消息顺序处理' },
      { id: 2, name: '顺序保证', description: '同一会话的消息必须按发送顺序处理' },
      { id: 3, name: '错误隔离', description: '单个消息处理失败不影响其他消息的处理' },
      { id: 4, name: '并发性能', description: '支持高并发消息处理，不同会话可以并行处理' },
      { id: 5, name: '群聊支持', description: '支持群聊会话隔离，群组内消息顺序处理' },
      { id: 6, name: '内存管理', description: '自动清理过期资源，避免内存泄漏' },
      { id: 7, name: '消息去抖动', description: '短时间内的重复消息自动合并' },
      { id: 8, name: '文本片段合并', description: '长文本片段自动合并' },
      { id: 9, name: '命令消息处理', description: '命令消息不参与合并，立即处理' },
      { id: 10, name: '超时保护', description: 'AI处理超时保护，防止长时间阻塞' }
    ];
  }

  // 测试1: 会话隔离
  async testSessionIsolation() {
    console.log('\n=== 测试要求1: 会话隔离 ===');
    
    this.queue.reset();
    const startTime = Date.now();
    
    const messages = [
      { from: 'user1', text: 'User1 Msg1', accountId: 'test', to: 'bot', chatType: ChatType.DM },
      { from: 'user2', text: 'User2 Msg1', accountId: 'test', to: 'bot', chatType: ChatType.DM },
      { from: 'user1', text: 'User1 Msg2', accountId: 'test', to: 'bot', chatType: ChatType.DM },
      { from: 'user2', text: 'User2 Msg2', accountId: 'test', to: 'bot', chatType: ChatType.DM }
    ];

    // 并发发送
    await Promise.all(messages.map(msg => this.queue.enqueue(msg, this.api)));
    
    // 等待处理完成
    await new Promise(resolve => setTimeout(resolve, 300));

    const totalTime = Date.now() - startTime;
    console.log(`处理4条消息耗时: ${totalTime}ms`);
    
    // 验证：用户1的消息应该按顺序，用户2的消息应该按顺序
    const user1Messages = this.queue.processOrder.filter(item => item.key.includes('user1'));
    const user2Messages = this.queue.processOrder.filter(item => item.key.includes('user2'));
    
    const user1OrderCorrect = user1Messages[0].message === 'User1 Msg1' && user1Messages[1].message === 'User1 Msg2';
    const user2OrderCorrect = user2Messages[0].message === 'User2 Msg1' && user2Messages[1].message === 'User2 Msg2';
    
    console.log(`用户1顺序正确: ${user1OrderCorrect}`);
    console.log(`用户2顺序正确: ${user2OrderCorrect}`);
    
    return user1OrderCorrect && user2OrderCorrect;
  }

  // 测试2: 顺序保证
  async testOrderGuarantee() {
    console.log('\n=== 测试要求2: 顺序保证 ===');
    
    this.queue.reset();
    const messages = [];
    
    for (let i = 1; i <= 5; i++) {
      messages.push({ 
        from: 'order_user', 
        text: `Message ${i}`, 
        accountId: 'test', 
        to: 'bot', 
        chatType: ChatType.DM 
      });
    }

    // 顺序发送
    for (const msg of messages) {
      await this.queue.enqueue(msg, this.api);
      await new Promise(resolve => setTimeout(resolve, 10));
    }

    // 等待处理完成
    await new Promise(resolve => setTimeout(resolve, 300));

    const orderUserMessages = this.queue.processOrder.filter(item => item.key.includes('order_user'));
    const orderCorrect = orderUserMessages.every((item, index) => item.message === `Message ${index + 1}`);
    
    console.log(`顺序保证测试: ${orderCorrect}`);
    console.log(`实际处理顺序: ${orderUserMessages.map(item => item.message).join(',')}`);
    
    return orderCorrect;
  }

  // 测试3: 错误隔离
  async testErrorIsolation() {
    console.log('\n=== 测试要求3: 错误隔离 ===');
    
    this.queue.reset();
    
    // 保存原始处理函数
    const originalProcessMessage = this.queue.processMessage;
    
    // 修改处理函数，让第二条消息失败
    let failCount = 0;
    this.queue.processMessage = async function(body, api) {
      if (body.text === 'Fail message') {
        failCount++;
        throw new Error('Simulated processing failure');
      }
      return originalProcessMessage.call(this, body, api);
    };

    const messages = [
      { from: 'error_user', text: 'Success 1', accountId: 'test', to: 'bot', chatType: ChatType.DM },
      { from: 'error_user', text: 'Fail message', accountId: 'test', to: 'bot', chatType: ChatType.DM },
      { from: 'error_user', text: 'Success 2', accountId: 'test', to: 'bot', chatType: ChatType.DM }
    ];

    for (const msg of messages) {
      await this.queue.enqueue(msg, this.api);
    }

    // 等待处理完成
    await new Promise(resolve => setTimeout(resolve, 300));

    const errorUserMessages = this.queue.processOrder.filter(item => item.key.includes('error_user'));
    const successCount = errorUserMessages.length;
    
    console.log(`成功处理消息数: ${successCount}`);
    console.log(`失败次数: ${failCount}`);
    
    // 恢复原始处理函数
    this.queue.processMessage = originalProcessMessage;
    
    // 验证：应该有2条成功消息，1条失败消息
    return successCount === 2 && failCount === 1;
  }

  // 测试4: 并发性能
  async testConcurrentPerformance() {
    console.log('\n=== 测试要求4: 并发性能 ===');
    
    this.queue.reset();
    const userCount = 5;
    const messagesPerUser = 10;
    const startTime = Date.now();
    
    const promises = [];
    
    for (let user = 1; user <= userCount; user++) {
      for (let msg = 1; msg <= messagesPerUser; msg++) {
        promises.push(this.queue.enqueue({
          from: `perf_user${user}`,
          text: `Message ${msg}`,
          accountId: 'test',
          to: 'bot',
          chatType: ChatType.DM
        }, this.api));
      }
    }
    
    await Promise.all(promises);
    
    // 等待处理完成
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const totalTime = Date.now() - startTime;
    const totalMessages = userCount * messagesPerUser;
    const avgTimePerMessage = totalTime / totalMessages;
    
    console.log(`处理 ${totalMessages} 条消息耗时: ${totalTime}ms`);
    console.log(`平均每条消息处理时间: ${avgTimePerMessage.toFixed(2)}ms`);
    
    // 验证：所有消息都应该被处理
    const processedCount = this.queue.processedMessages.length;
    console.log(`实际处理消息数: ${processedCount}`);
    
    return processedCount === totalMessages;
  }

  // 测试5: 群聊支持
  async testGroupChatSupport() {
    console.log('\n=== 测试要求5: 群聊支持 ===');
    
    this.queue.reset();
    
    const groupMessages = [
      { from: 'userA', text: 'Group msg 1', accountId: 'test', to: 'group1', chatType: ChatType.Group, gid: 'group123' },
      { from: 'userB', text: 'Group msg 2', accountId: 'test', to: 'group1', chatType: ChatType.Group, gid: 'group123' },
      { from: 'userA', text: 'Group msg 3', accountId: 'test', to: 'group1', chatType: ChatType.Group, gid: 'group123' }
    ];

    for (const msg of groupMessages) {
      await this.queue.enqueue(msg, this.api);
    }

    // 等待处理完成
    await new Promise(resolve => setTimeout(resolve, 300));

    const groupMessagesProcessed = this.queue.processOrder.filter(item => item.key.includes('group123'));
    const orderCorrect = groupMessagesProcessed.every((item, index) => {
      return item.message === `Group msg ${index + 1}`;
    });
    
    console.log(`群聊顺序测试: ${orderCorrect}`);
    console.log(`群聊处理顺序: ${groupMessagesProcessed.map(item => item.message).join(',')}`);
    
    return orderCorrect;
  }

  // 测试6: 内存管理
  async testMemoryManagement() {
    console.log('\n=== 测试要求6: 内存管理 ===');
    
    this.queue.reset();
    
    // 发送一些消息
    for (let i = 0; i < 10; i++) {
      await this.queue.enqueue({
        from: 'memory_user',
        text: `Memory test ${i}`,
        accountId: 'test',
        to: 'bot',
        chatType: ChatType.DM
      }, this.api);
    }

    // 等待处理完成
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // 执行清理
    this.queue.cleanup();
    
    // 检查队列是否为空
    const hasEmptyQueues = Array.from(this.queue.queues.values()).every(queue => queue.length === 0);
    const processingStatus = Array.from(this.queue.processing.values()).every(status => !status);
    
    console.log(`队列清理测试: ${hasEmptyQueues && processingStatus}`);
    console.log(`队列数量: ${this.queue.queues.size}`);
    console.log(`处理状态数量: ${this.queue.processing.size}`);
    
    return hasEmptyQueues && processingStatus;
  }

  // 测试7: 消息去抖动
  async testDebounce() {
    console.log('\n=== 测试要求7: 消息去抖动 ===');
    
    this.queue.reset();
    const startTime = Date.now();
    
    // 短时间内发送相同用户的多条消息
    for (let i = 0; i < 5; i++) {
      await this.queue.enqueue({
        from: 'debounce_user',
        text: `Debounce message ${i + 1}`,
        accountId: 'test',
        to: 'bot',
        chatType: ChatType.DM
      }, this.api);
      await new Promise(resolve => setTimeout(resolve, 20)); // 20ms间隔
    }

    // 等待去抖动处理完成
    await new Promise(resolve => setTimeout(resolve, 200));
    
    const totalTime = Date.now() - startTime;
    const debounceMessages = this.queue.processOrder.filter(item => item.key.includes('debounce_user'));
    
    console.log(`去抖动测试耗时: ${totalTime}ms`);
    console.log(`实际处理消息数: ${debounceMessages.length}`);
    console.log(`处理的消息: ${debounceMessages.map(item => item.message).join(',')}`);
    
    // 去抖动应该只保留最后一条消息
    return debounceMessages.length === 1 && debounceMessages[0].message === 'Debounce message 5';
  }

  // 测试8: 文本片段合并
  async testTextFragmentMerge() {
    console.log('\n=== 测试要求8: 文本片段合并 ===');
    
    this.queue.reset();
    
    // 创建长文本片段
    const longTextPart1 = 'A'.repeat(4500); // 超过4000字符的阈值
    const longTextPart2 = 'B'.repeat(1000);
    
    await this.queue.enqueue({
      from: 'fragment_user',
      text: longTextPart1,
      accountId: 'test',
      to: 'bot',
      chatType: ChatType.DM
    }, this.api);
    
    // 模拟分段发送
    await new Promise(resolve => setTimeout(resolve, 100));
    
    await this.queue.enqueue({
      from: 'fragment_user',
      text: longTextPart2,
      accountId: 'test',
      to: 'bot',
      chatType: ChatType.DM
    }, this.api);

    // 等待合并处理完成
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const fragmentMessages = this.queue.processOrder.filter(item => item.key.includes('fragment_user'));
    const mergedText = fragmentMessages[0]?.message || '';
    
    console.log(`文本片段合并测试: ${fragmentMessages.length === 1}`);
    console.log(`合并后的文本长度: ${mergedText.length}`);
    
    return fragmentMessages.length === 1 && mergedText.length === 5500;
  }

  // 测试9: 命令消息处理
  async testCommandMessageHandling() {
    console.log('\n=== 测试要求9: 命令消息处理 ===');
    
    this.queue.reset();
    
    const commands = [
      { from: 'command_user', text: '/help', accountId: 'test', to: 'bot', chatType: ChatType.DM },
      { from: 'command_user', text: '/settings', accountId: 'test', to: 'bot', chatType: ChatType.DM }
    ];

    for (const cmd of commands) {
      await this.queue.enqueue(cmd, this.api);
      await new Promise(resolve => setTimeout(resolve, 50));
    }

    // 等待处理完成
    await new Promise(resolve => setTimeout(resolve, 300));
    
    const commandMessages = this.queue.processOrder.filter(item => item.key.includes('command_user'));
    
    console.log(`命令消息测试: ${commandMessages.length === 2}`);
    console.log(`处理的命令: ${commandMessages.map(item => item.message).join(',')}`);
    
    return commandMessages.length === 2;
  }

  // 运行所有测试
  async runAllTests() {
    console.log('=== 消息队列核心要求测试 ===\n');
    
    const requirements = this.getRequirements();
    const tests = [
      { name: '会话隔离', test: () => this.testSessionIsolation() },
      { name: '顺序保证', test: () => this.testOrderGuarantee() },
      { name: '错误隔离', test: () => this.testErrorIsolation() },
      { name: '并发性能', test: () => this.testConcurrentPerformance() },
      { name: '群聊支持', test: () => this.testGroupChatSupport() },
      { name: '内存管理', test: () => this.testMemoryManagement() },
      { name: '消息去抖动', test: () => this.testDebounce() },
      { name: '文本片段合并', test: () => this.testTextFragmentMerge() },
      { name: '命令消息处理', test: () => this.testCommandMessageHandling() }
    ];

    let passed = 0;
    let total = tests.length;

    console.log('消息队列核心要求:');
    requirements.forEach(req => {
      console.log(`  ${req.id}. ${req.name}: ${req.description}`);
    });
    console.log();

    for (const { name, test } of tests) {
      try {
        const result = await test();
        if (result) {
          console.log(`✅ ${name}: 通过`);
          passed++;
        } else {
          console.log(`❌ ${name}: 失败`);
        }
      } catch (error) {
        console.log(`❌ ${name}: 异常 - ${error.message}`);
      }
    }

    console.log(`\n=== 测试结果: ${passed}/${total} 通过 ===`);
    
    return passed === total;
  }
}

// 运行测试
async function main() {
  console.log('开始消息队列核心要求测试...\n');
  
  const test = new QueueRequirementsTest();
  await test.runAllTests();
  
  console.log('\n=== 测试完成 ===');
}

// 运行测试
main().catch(console.error);
