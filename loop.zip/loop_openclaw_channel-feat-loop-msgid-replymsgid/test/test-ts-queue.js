// 测试TypeScript队列功能的JavaScript文件

// 模拟ChatType枚举
const ChatType = {
  DM: 'dm',
  Group: 'group'
};

// 模拟处理函数
async function mockProcessMessage(body, api) {
  console.log(`Processing message: ${body.text} from ${body.from}`);
  await new Promise(resolve => setTimeout(resolve, 50));
}

// 导入编译后的队列类
const { SessionIsolatedQueue } = require('../dist/queue.js');

async function testQueue() {
  console.log('测试TypeScript队列功能...');
  
  // 创建队列实例
  const queue = new SessionIsolatedQueue(mockProcessMessage);
  
  // 测试消息
  const messages = [
    {
      from: 'testuser',
      text: 'Hello from test',
      accountId: 'test',
      to: 'bot',
      chatType: ChatType.DM
    },
    {
      from: 'testuser',
      text: 'Second message',
      accountId: 'test',
      to: 'bot',
      chatType: ChatType.DM
    }
  ];
  
  // 发送消息
  console.log('发送消息...');
  for (const msg of messages) {
    await queue.enqueue(msg, {});
    await new Promise(resolve => setTimeout(resolve, 10));
  }
  
  // 等待处理完成
  await new Promise(resolve => setTimeout(resolve, 200));
  
  console.log('测试完成！');
}

// 运行测试
testQueue().catch(console.error);
