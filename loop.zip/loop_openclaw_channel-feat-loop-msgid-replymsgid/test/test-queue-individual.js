// 消息队列核心要求单独测试

// 模拟ChatType枚举
const ChatType = {
  DM: 'dm',
  Group: 'group'
};

// 基础消息队列类（禁用去抖动和文本合并，用于测试基础功能）
class BasicSessionQueue {
  constructor() {
    this.queues = new Map();
    this.processing = new Map();
    this.processedMessages = [];
    this.processOrder = [];
    this.errorCount = 0;
  }

  getSessionKey(body) {
    const chatType = body.chatType || ChatType.DM;
    return chatType === ChatType.DM 
      ? `loop:${body.accountId}:${body.from}` 
      : `loop:${body.accountId}:group:${body.gid || body.to}`;
  }

  async enqueue(body, api) {
    const key = this.getSessionKey(body);
    const queue = this.queues.get(key) || [];
    queue.push({ body, api });
    this.queues.set(key, queue);

    if (!this.processing.get(key)) {
      this.processNext(key);
    }
  }

  async processMessage(body, api) {
    this.processedMessages.push(body);
    this.processOrder.push({ 
      key: this.getSessionKey(body), 
      message: body.text,
      timestamp: Date.now()
    });
    
    // 模拟处理延迟
    await new Promise(resolve => setTimeout(resolve, 50));
  }

  async processNext(key) {
    const queue = this.queues.get(key) || [];
    
    if (queue.length === 0) {
      this.processing.set(key, false);
      return;
    }

    this.processing.set(key, true);
    const item = queue.shift();

    if (item) {
      try {
        await this.processMessage(item.body, item.api);
      } catch (error) {
        this.errorCount++;
        console.error(`Error processing message for session ${key}:`, error);
      } finally {
        this.processNext(key);
      }
    }
  }

  reset() {
    this.queues.clear();
    this.processing.clear();
    this.processedMessages = [];
    this.processOrder = [];
    this.errorCount = 0;
  }
}

// 完整消息队列类（包含去抖动和文本合并）
class CompleteSessionQueue extends BasicSessionQueue {
  constructor() {
    super();
    this.debounceBuffer = new Map();
    this.textFragmentBuffer = new Map();
  }

  // 去抖动处理
  handleDebounce(entry) {
    const key = this.getSessionKey(entry.body);
    const existing = this.debounceBuffer.get(key);

    if (existing) {
      clearTimeout(existing.timer);
    }

    const timer = setTimeout(async () => {
      this.debounceBuffer.delete(key);
      await super.enqueue(entry.body, entry.api);
    }, 100); // 100ms去抖动

    this.debounceBuffer.set(key, {
      ...entry,
      timer,
    });
  }

  // 文本片段处理
  handleTextFragment(item) {
    const { body } = item;
    const text = body.text || "";
    const isCommandLike = text.trim().startsWith("/");

    if (!text || isCommandLike) {
      return false;
    }

    const key = this.getSessionKey(body);
    const existing = this.textFragmentBuffer.get(key);

    if (existing) {
      const last = existing.messages.at(-1);
      const lastReceivedAtMs = last?.receivedAtMs ?? item.receivedAtMs;
      const timeGapMs = item.receivedAtMs - lastReceivedAtMs;

      const canAppend = timeGapMs >= 0 && timeGapMs <= 1500;

      if (canAppend) {
        const currentTotalChars = existing.messages.reduce(
          (sum, m) => sum + (m.body.text?.length ?? 0),
          0
        );
        const nextTotalChars = currentTotalChars + text.length;

        if (
          existing.messages.length + 1 <= 12 &&
          nextTotalChars <= 50000
        ) {
          existing.messages.push({
            body: { ...body, text: text },
            api: item.api,
            receivedAtMs: item.receivedAtMs,
          });
          this.scheduleTextFragmentFlush(existing);
          return true;
        }
      }

      this.flushTextFragment(existing);
    }

    const shouldStart = text.length >= 4000;
    if (shouldStart) {
      const entry = {
        key,
        messages: [{ body: { ...body, text }, api: item.api, receivedAtMs: item.receivedAtMs }],
        timer: setTimeout(() => {}, 1500),
      };
      this.textFragmentBuffer.set(key, entry);
      this.scheduleTextFragmentFlush(entry);
      return true;
    }

    return false;
  }

  scheduleTextFragmentFlush(entry) {
    clearTimeout(entry.timer);
    entry.timer = setTimeout(() => {
      this.flushTextFragment(entry);
    }, 1500);
  }

  async flushTextFragment(entry) {
    this.textFragmentBuffer.delete(entry.key);
    
    if (entry.messages.length === 0) {
      return;
    }

    const combinedText = entry.messages
      .map((m) => m.body.text || "")
      .filter(Boolean)
      .join("");

    if (!combinedText.trim()) {
      return;
    }

    const first = entry.messages[0];
    const mergedBody = {
      ...first.body,
      text: combinedText,
      id: entry.messages.at(-1)?.body.id || first.body.id,
    };

    await super.enqueue(mergedBody, first.api);
  }

  async enqueue(body, api) {
    const receivedAtMs = Date.now();
    const item = { body, api, receivedAtMs };

    if (this.handleTextFragment(item)) {
      return;
    }

    this.handleDebounce({ body, api, receivedAtMs });
  }

  reset() {
    super.reset();
    this.debounceBuffer.clear();
    this.textFragmentBuffer.clear();
  }
}

// 测试类
class QueueRequirementsTest {
  constructor() {
    this.basicQueue = new BasicSessionQueue();
    this.completeQueue = new CompleteSessionQueue();
    this.api = {};
  }

  // 测试要求1: 会话隔离（基础队列）
  async testSessionIsolation() {
    console.log('\n=== 测试要求1: 会话隔离 ===');
    
    this.basicQueue.reset();
    
    const messages = [
      { from: 'user1', text: 'User1 Msg1', accountId: 'test', to: 'bot', chatType: ChatType.DM },
      { from: 'user2', text: 'User2 Msg1', accountId: 'test', to: 'bot', chatType: ChatType.DM },
      { from: 'user1', text: 'User1 Msg2', accountId: 'test', to: 'bot', chatType: ChatType.DM },
      { from: 'user2', text: 'User2 Msg2', accountId: 'test', to: 'bot', chatType: ChatType.DM }
    ];

    // 并发发送
    await Promise.all(messages.map(msg => this.basicQueue.enqueue(msg, this.api)));
    
    // 等待处理完成
    await new Promise(resolve => setTimeout(resolve, 300));

    // 验证：应该有4条消息被处理
    const processedCount = this.basicQueue.processedMessages.length;
    console.log(`处理消息数: ${processedCount}`);
    
    // 验证每个用户都有2条消息
    const user1Count = this.basicQueue.processOrder.filter(item => item.key.includes('user1')).length;
    const user2Count = this.basicQueue.processOrder.filter(item => item.key.includes('user2')).length;
    
    console.log(`用户1消息数: ${user1Count}`);
    console.log(`用户2消息数: ${user2Count}`);
    
    return processedCount === 4 && user1Count === 2 && user2Count === 2;
  }

  // 测试要求2: 顺序保证（基础队列）
  async testOrderGuarantee() {
    console.log('\n=== 测试要求2: 顺序保证 ===');
    
    this.basicQueue.reset();
    
    const messages = [];
    for (let i = 1; i <= 3; i++) {
      messages.push({ 
        from: 'order_user', 
        text: `Message ${i}`, 
        accountId: 'test', 
        to: 'bot', 
        chatType: ChatType.DM 
      });
    }

    // 顺序发送，确保有足够间隔避免并发
    for (const msg of messages) {
      await this.basicQueue.enqueue(msg, this.api);
      await new Promise(resolve => setTimeout(resolve, 100));
    }

    // 等待处理完成
    await new Promise(resolve => setTimeout(resolve, 300));

    const orderMessages = this.basicQueue.processOrder.filter(item => item.key.includes('order_user'));
    const orderCorrect = orderMessages.every((item, index) => item.message === `Message ${index + 1}`);
    
    console.log(`顺序保证测试: ${orderCorrect}`);
    console.log(`处理顺序: ${orderMessages.map(item => item.message).join(',')}`);
    
    return orderCorrect;
  }

  // 测试要求3: 错误隔离（基础队列）
  async testErrorIsolation() {
    console.log('\n=== 测试要求3: 错误隔离 ===');
    
    this.basicQueue.reset();
    
    // 保存原始处理函数
    const originalProcessMessage = this.basicQueue.processMessage;
    
    // 修改处理函数，让第二条消息失败
    let failCount = 0;
    this.basicQueue.processMessage = async function(body, api) {
      if (body.text === 'Fail message') {
        failCount++;
        throw new Error('Simulated processing failure');
      }
      return originalProcessMessage.call(this, body, api);
    };

    const messages = [
      { from: 'error_user', text: 'Success 1', accountId: 'test', to: 'bot', chatType: ChatType.DM },
      { from: 'error_user', text: 'Fail message', accountId: 'test', to: 'bot', chatType: ChatType.DM },
      { from: 'error_user', text: 'Success 2', accountId: 'test', to: 'bot', chatType: ChatType.DM }
    ];

    for (const msg of messages) {
      await this.basicQueue.enqueue(msg, this.api);
      await new Promise(resolve => setTimeout(resolve, 100));
    }

    // 等待处理完成
    await new Promise(resolve => setTimeout(resolve, 500));

    const errorMessages = this.basicQueue.processOrder.filter(item => item.key.includes('error_user'));
    const successCount = errorMessages.length;
    
    console.log(`成功处理消息数: ${successCount}`);
    console.log(`失败次数: ${failCount}`);
    console.log(`处理的消息: ${errorMessages.map(item => item.message).join(',')}`);
    
    // 恢复原始处理函数
    this.basicQueue.processMessage = originalProcessMessage;
    
    // 验证：应该有2条成功消息
    return successCount === 2;
  }

  // 测试要求4: 并发性能（基础队列）
  async testConcurrentPerformance() {
    console.log('\n=== 测试要求4: 并发性能 ===');
    
    this.basicQueue.reset();
    const userCount = 3;
    const messagesPerUser = 5;
    const startTime = Date.now();
    
    const promises = [];
    
    for (let user = 1; user <= userCount; user++) {
      for (let msg = 1; msg <= messagesPerUser; msg++) {
        promises.push(this.basicQueue.enqueue({
          from: `perf_user${user}`,
          text: `Message ${msg}`,
          accountId: 'test',
          to: 'bot',
          chatType: ChatType.DM
        }, this.api));
      }
    }
    
    await Promise.all(promises);
    
    // 等待处理完成
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const totalTime = Date.now() - startTime;
    const totalMessages = userCount * messagesPerUser;
    const processedCount = this.basicQueue.processedMessages.length;
    
    console.log(`处理 ${totalMessages} 条消息耗时: ${totalTime}ms`);
    console.log(`实际处理消息数: ${processedCount}`);
    
    return processedCount === totalMessages;
  }

  // 测试要求5: 群聊支持（基础队列）
  async testGroupChatSupport() {
    console.log('\n=== 测试要求5: 群聊支持 ===');
    
    this.basicQueue.reset();
    
    const groupMessages = [
      { from: 'userA', text: 'Group msg 1', accountId: 'test', to: 'group1', chatType: ChatType.Group, gid: 'group123' },
      { from: 'userB', text: 'Group msg 2', accountId: 'test', to: 'group1', chatType: ChatType.Group, gid: 'group123' },
      { from: 'userA', text: 'Group msg 3', accountId: 'test', to: 'group1', chatType: ChatType.Group, gid: 'group123' }
    ];

    for (const msg of groupMessages) {
      await this.basicQueue.enqueue(msg, this.api);
      await new Promise(resolve => setTimeout(resolve, 100));
    }

    // 等待处理完成
    await new Promise(resolve => setTimeout(resolve, 300));

    const groupMessagesProcessed = this.basicQueue.processOrder.filter(item => item.key.includes('group123'));
    const countCorrect = groupMessagesProcessed.length === 3;
    
    console.log(`群聊消息处理数: ${groupMessagesProcessed.length}`);
    console.log(`群聊处理顺序: ${groupMessagesProcessed.map(item => item.message).join(',')}`);
    
    return countCorrect;
  }

  // 测试要求6: 消息去抖动（完整队列）
  async testDebounce() {
    console.log('\n=== 测试要求6: 消息去抖动 ===');
    
    this.completeQueue.reset();
    
    // 短时间内发送相同用户的多条消息
    for (let i = 0; i < 3; i++) {
      await this.completeQueue.enqueue({
        from: 'debounce_user',
        text: `Debounce message ${i + 1}`,
        accountId: 'test',
        to: 'bot',
        chatType: ChatType.DM
      }, this.api);
      await new Promise(resolve => setTimeout(resolve, 20)); // 20ms间隔
    }

    // 等待去抖动处理完成
    await new Promise(resolve => setTimeout(resolve, 200));
    
    const debounceMessages = this.completeQueue.processOrder.filter(item => item.key.includes('debounce_user'));
    
    console.log(`去抖动处理消息数: ${debounceMessages.length}`);
    console.log(`处理的消息: ${debounceMessages.map(item => item.message).join(',')}`);
    
    // 去抖动应该只保留最后一条消息
    return debounceMessages.length === 1 && debounceMessages[0].message === 'Debounce message 3';
  }

  // 测试要求7: 文本片段合并（完整队列）
  async testTextFragmentMerge() {
    console.log('\n=== 测试要求7: 文本片段合并 ===');
    
    this.completeQueue.reset();
    
    // 创建长文本片段
    const longTextPart1 = 'A'.repeat(4500);
    const longTextPart2 = 'B'.repeat(1000);
    
    await this.completeQueue.enqueue({
      from: 'fragment_user',
      text: longTextPart1,
      accountId: 'test',
      to: 'bot',
      chatType: ChatType.DM
    }, this.api);
    
    // 模拟分段发送
    await new Promise(resolve => setTimeout(resolve, 100));
    
    await this.completeQueue.enqueue({
      from: 'fragment_user',
      text: longTextPart2,
      accountId: 'test',
      to: 'bot',
      chatType: ChatType.DM
    }, this.api);

    // 等待合并处理完成
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const fragmentMessages = this.completeQueue.processOrder.filter(item => item.key.includes('fragment_user'));
    const mergedText = fragmentMessages[0]?.message || '';
    
    console.log(`文本片段合并测试: ${fragmentMessages.length === 1}`);
    console.log(`合并后的文本长度: ${mergedText.length}`);
    
    return fragmentMessages.length === 1 && mergedText.length === 5500;
  }

  // 测试要求8: 命令消息处理（完整队列）
  async testCommandMessageHandling() {
    console.log('\n=== 测试要求8: 命令消息处理 ===');
    
    this.completeQueue.reset();
    
    const commands = [
      { from: 'command_user', text: '/help', accountId: 'test', to: 'bot', chatType: ChatType.DM },
      { from: 'command_user', text: '/settings', accountId: 'test', to: 'bot', chatType: ChatType.DM }
    ];

    for (const cmd of commands) {
      await this.completeQueue.enqueue(cmd, this.api);
      await new Promise(resolve => setTimeout(resolve, 200)); // 足够间隔避免去抖动
    }

    // 等待处理完成
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const commandMessages = this.completeQueue.processOrder.filter(item => item.key.includes('command_user'));
    
    console.log(`命令消息测试: ${commandMessages.length === 2}`);
    console.log(`处理的命令: ${commandMessages.map(item => item.message).join(',')}`);
    
    return commandMessages.length === 2;
  }

  // 运行所有测试
  async runAllTests() {
    console.log('=== 消息队列核心要求测试 ===\n');
    
    const tests = [
      { name: '会话隔离', test: () => this.testSessionIsolation() },
      { name: '顺序保证', test: () => this.testOrderGuarantee() },
      { name: '错误隔离', test: () => this.testErrorIsolation() },
      { name: '并发性能', test: () => this.testConcurrentPerformance() },
      { name: '群聊支持', test: () => this.testGroupChatSupport() },
      { name: '消息去抖动', test: () => this.testDebounce() },
      { name: '文本片段合并', test: () => this.testTextFragmentMerge() },
      { name: '命令消息处理', test: () => this.testCommandMessageHandling() }
    ];

    let passed = 0;
    let total = tests.length;

    console.log('消息队列核心要求:');
    console.log('  1. 会话隔离: 不同用户的消息可以并发处理');
    console.log('  2. 顺序保证: 同一会话的消息必须按顺序处理');
    console.log('  3. 错误隔离: 单个消息处理失败不影响其他消息');
    console.log('  4. 并发性能: 支持高并发消息处理');
    console.log('  5. 群聊支持: 支持群聊会话隔离');
    console.log('  6. 消息去抖动: 短时间内的重复消息自动合并');
    console.log('  7. 文本片段合并: 长文本片段自动合并');
    console.log('  8. 命令消息处理: 命令消息不参与合并');
    console.log();

    for (const { name, test } of tests) {
      try {
        const result = await test();
        if (result) {
          console.log(`✅ ${name}: 通过`);
          passed++;
        } else {
          console.log(`❌ ${name}: 失败`);
        }
      } catch (error) {
        console.log(`❌ ${name}: 异常 - ${error.message}`);
      }
    }

    console.log(`\n=== 测试结果: ${passed}/${total} 通过 ===`);
    
    return passed === total;
  }
}

// 运行测试
async function main() {
  console.log('开始消息队列核心要求测试...\n');
  
  const test = new QueueRequirementsTest();
  await test.runAllTests();
  
  console.log('\n=== 测试完成 ===');
}

// 运行测试
main().catch(console.error);
