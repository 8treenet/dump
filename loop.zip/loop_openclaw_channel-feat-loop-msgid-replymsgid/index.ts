import type { OpenClawPluginApi } from "openclaw/plugin-sdk";
import { loopChannel } from "./src/channel.ts";
import { registerWebHook } from "./src/webhook.ts";

export default async function (api: OpenClawPluginApi) {
  api.registerChannel({ plugin: loopChannel });
  registerWebHook(api);
  console.log("loop plugin initialized");
}