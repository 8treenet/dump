import { mkdir, appendFile } from "fs/promises";
import { join } from "path";
import { workspaceDir } from "./const.ts";

export async function writeLog(message: string): Promise<void> {
  try {
    await mkdir(workspaceDir, { recursive: true });
    
    const logFile = join(workspaceDir, "looplog");
    const timestamp = new Date().toISOString();
    const logMessage = `[${timestamp}] ${message}\n`;
    
    await appendFile(logFile, logMessage);
  } catch (error) {
    console.error("Failed to write log:", error);
  }
}