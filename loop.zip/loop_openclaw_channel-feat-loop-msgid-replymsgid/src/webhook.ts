import type { OpenClawPluginApi, ReplyPayload } from "openclaw/plugin-sdk";
import { sendLoopMessage } from "./loopmsg.ts";
import { downloadFile, ChatType, buildSender } from "./tools.ts";
import { SessionIsolatedQueue } from "./queue.ts";

const webhookPath = "/loop/webhook";

type LoopWebhookRequestBody = {
  from?: string;
  to?: string;
  text?: string;
  accountId?: string;
  chatType?: string;
  gid?: string;
  id?: string;
  msgId?: string;
  mediaUrl?: string;
  mediaType?: string;
  [key: string]: unknown;
};

type LoopWebhookBody = {
  from: string;
  to: string;
  text: string;
  accountId: string;
  chatType?: ChatType;
  gid?: string;
  id?: string;
  msgId?: string;
  mediaUrl?: string;
  mediaType?: string;
  [key: string]: unknown;
};

// Webhook配置
const LOOP_WEBHOOK_MAX_BODY_BYTES = 1024 * 1024; // 1MB
const LOOP_AI_PROCESSING_TIMEOUT_MS = 600_000_000; // AI处理超时时间（600秒）

/**
 * 解析请求体
 */
async function parseRequestBody(req: any): Promise<{ ok: boolean; value?: any; error?: string; code?: string }> {
  return new Promise((resolve) => {
    let bodyData = '';
    let receivedBytes = 0;

    req.on('data', (chunk: Buffer) => {
      receivedBytes += chunk.length;
      
      // 检查大小限制
      if (receivedBytes > LOOP_WEBHOOK_MAX_BODY_BYTES) {
        req.destroy(new Error('Payload too large'));
        resolve({
          ok: false,
          error: `Payload too large. Maximum size is ${LOOP_WEBHOOK_MAX_BODY_BYTES / 1024 / 1024}MB`,
          code: 'PAYLOAD_TOO_LARGE'
        });
        return;
      }
      
      bodyData += chunk.toString();
    });
    
    req.on('end', () => {
      try {
        const body = bodyData ? JSON.parse(bodyData) : {};
        resolve({ ok: true, value: body });
      } catch (error) {
        console.error("[LoopChannel] Failed to parse body:", error);
        resolve({
          ok: false,
          error: 'Invalid JSON',
          code: 'INVALID_JSON'
        });
      }
    });
    
    req.on('error', (error: any) => {
      console.error("[LoopChannel] Request error:", error);
      resolve({
        ok: false,
        error: 'Connection closed',
        code: 'CONNECTION_CLOSED'
      });
    });
  });
}

/**
 * 验证请求参数
 */
function validateRequest(body: LoopWebhookRequestBody): asserts body is LoopWebhookBody {
  if (!body.from || !body.text || !body.accountId || !body.to) {
    throw new Error("Missing required fields: from, text, accountId, to");
  }
}

function resolveLoopChatType(chatType?: string): ChatType {
  return chatType === ChatType.GROUP ? ChatType.GROUP : ChatType.DM;
}

/**
 * 处理媒体文件
 */
async function processMedia(body: LoopWebhookBody): Promise<{ mediaPath: string; mediaType: string }> {
  let mediaPath = "";
  let mediaType = "";
  
  if (body.mediaUrl) {
    try {
      mediaPath = await downloadFile(body.mediaUrl) || "";
      mediaType = body.mediaType || "";
      if (mediaPath) {
        body.text += `\n[local Media path: ${mediaPath}]`;
      }
    } catch (error) {
      console.error("[LoopChannel] Failed to download media:", error);
      // 媒体下载失败不应该影响消息处理，继续处理文本部分
    }
  }
  
  return { mediaPath, mediaType };
}

/**
 * 构建消息上下文
 */
function buildMessageContext(body: LoopWebhookBody, api: OpenClawPluginApi, mediaPath: string, mediaType: string) {
  const loopChatType = body.chatType || ChatType.DM;
  const loopSender = buildSender(body.from, body.to, loopChatType, body.gid);
  const messageSid = body.msgId || body.id || `msg-${Date.now()}`;

  // 在消息文本中添加思考指令来启用思考模式
  const messageWithThink = `/think:high /reasoning on ${body.text}`;

  // let sessionKey = `loop_session_${body.from}`;
  // if (loopChatType === ChatType.GROUP) {
  //   sessionKey = `loop_group_session:${body.gid}:${body.from}`;
  // }

  let sessionKey = `loop:dm:${body.from}`;
  if (loopChatType === ChatType.GROUP) {
    sessionKey = `loop:group:${body.gid}`;
  }
  
  let chatType = ChatType.DM;
  if (loopChatType === ChatType.GROUP) {
    chatType = ChatType.GROUP;
  }

  console.log(`[LoopChannel] chatType: ${chatType}, sessionKey: ${sessionKey}`);

  return api.runtime.channel.reply.finalizeInboundContext({
    From: `${body.from}`,
    To: loopSender,
    Body: messageWithThink,
    RawBody: messageWithThink,
    CommandBody: messageWithThink,
    SessionKey: sessionKey,
    AccountId: body.accountId || "default",
    ChatType: chatType,
    ConversationLabel: `user:${body.from}`,
    SenderId: body.from,
    Provider: "loop",
    Surface: "loop",
    MessageSid: messageSid,
    Timestamp: Date.now(),
    OriginatingChannel: "loop" as const,
    OriginatingTo: loopSender,
    MediaPath: mediaPath,
    MediaType: mediaType,
  });
}

/**
 * 处理消息（放入队列后处理）
 */
export async function processMessage(body: LoopWebhookBody, api: OpenClawPluginApi): Promise<void> {
  console.log("[LoopChannel] Processing message:", body);

  try {
    // 处理媒体文件
    const { mediaPath, mediaType } = await processMedia(body);

    // 构建消息上下文
    const messageContext = buildMessageContext(body, api, mediaPath, mediaType);

    // 创建超时Promise
    const timeoutPromise = new Promise<never>((_, reject) => {
      setTimeout(() => {
        reject(new Error(`AI processing timeout after ${LOOP_AI_PROCESSING_TIMEOUT_MS / 1000}s`));
      }, LOOP_AI_PROCESSING_TIMEOUT_MS);
    });

    // 发送给OpenClaw AI处理（带超时）
    await Promise.race([
      console.log(`[LoopChannel] send to OpenClaw AI for:`, messageContext),
      api.runtime.channel.reply.dispatchReplyWithBufferedBlockDispatcher({
        ctx: messageContext,
        cfg: api.config,
        dispatcherOptions: {
          deliver: async (payload: ReplyPayload & { isReasoning?: boolean }) => {
            console.log("[LoopChannel] AI Reply received:", payload);
            const loopChatType = body.chatType || ChatType.DM;
            try {
              await sendLoopMessage(payload, body.from, loopChatType, body.gid, body.msgId || body.id);
            } catch (sendError) {
              console.error("[LoopChannel] Failed to send reply message:", sendError);
              // 发送失败不应该影响整体流程
            }
          },
        },
      }),
      timeoutPromise
    ]);
  } catch (error) {
    console.error("[LoopChannel] Error processing message:", error);
    
    // 如果是超时错误，发送超时提示
    if ((error as Error).message.includes("AI processing timeout")) {
      try {
        const loopChatType = body.chatType || ChatType.DM;
        await sendLoopMessage(
          { text: `AI processing timed out, please try again later (timeout: ${LOOP_AI_PROCESSING_TIMEOUT_MS / 1000} seconds)` },
          body.from,
          loopChatType,
          body.gid,
          body.msgId || body.id
        );
      } catch (sendError) {
        console.error("[LoopChannel] Failed to send timeout message:", sendError);
      }
    }
    
    throw error;
  }
}

// 创建消息队列实例
const messageQueue = new SessionIsolatedQueue(processMessage);

// 定期清理
setInterval(() => {
  messageQueue.cleanup();
}, 60_000); // 每分钟清理一次

/**
 * 注册Webhook路由
 */
export function registerWebHook(api: OpenClawPluginApi) {
  
  api.registerHttpRoute({
    path: webhookPath,
    auth: "plugin",
    handler: async (req, res) => {
      try {
        // 解析请求体
        const bodyResult = await parseRequestBody(req);
        
        if (!bodyResult.ok) {
          let statusCode = 400;
          if (bodyResult.code === "PAYLOAD_TOO_LARGE") {
            statusCode = 413;
          } else if (bodyResult.code === "REQUEST_BODY_TIMEOUT") {
            statusCode = 408;
          }
          
          res.statusCode = statusCode;
          res.end(JSON.stringify({ error: bodyResult.error }));
          return;
        }

        const body = bodyResult.value as LoopWebhookRequestBody;
        console.log(`[LoopChannel] Webhook received at ${new Date().toISOString()} with id: ${body.msgId || body.id || 'unknown'}, from: ${body.from}, text: ${(body.text || "").substring(0, 50)}...`);

        // 验证请求参数
        validateRequest(body);
        const normalizedBody: LoopWebhookBody = {
          ...body,
          chatType: resolveLoopChatType(body.chatType),
        };

        res.statusCode = 200;
        res.end();

        // 将消息放入队列，顺序处理
        await messageQueue.enqueue(normalizedBody, api);
      } catch (error) {
        console.error("[LoopChannel] Webhook error:", error);
        res.statusCode = 400;
        res.end(JSON.stringify({ error: (error as Error).message }));
      }
    },
  });
}
