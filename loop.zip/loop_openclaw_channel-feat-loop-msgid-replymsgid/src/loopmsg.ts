import type { ReplyPayload } from "openclaw/plugin-sdk";
import { uploadMediaUrlToOss, getLoopApiUrl, getLoopToken,  getLocalFileInfo, getFileType, isLocalFilePath, localFileExists, ChatType } from "./tools.ts";

// Get loop API URL
const url = getLoopApiUrl();
const token = getLoopToken();

type LoopSendRequestBody = {
    chat_type: ChatType;
    xid: string;
    gid?: string;
    type: "text" | "img" | "video" | "file";
    msg?: string;
    replyMsgId?: string;
    img?: {
        url: string;
        width: number;
        height: number;
        size: number;
        type: string;
    };
    video?: {
        url: string;
        size: number;
        type: string;
    };
    file?: {
        url: string;
        name: string;
        size: number;
        type: string;
    };
};

function withReplyMsgId(replyMsgId?: string): Pick<LoopSendRequestBody, "replyMsgId"> | Record<string, never> {
    return replyMsgId ? { replyMsgId } : {};
}

export async function sendLoopMessage(payload: ReplyPayload & {isReasoning?:boolean}, to: string, chatType: ChatType = ChatType.DM, gid?: string, fallbackReplyMsgId?: string) {
    const cleanText = payload.text?.trim() || "";
    const replyMsgId = payload.replyToId || fallbackReplyMsgId;

    console.log("[LoopChannel] sendLoopMessage resolved reply target:", {
        to,
        chatType,
        gid,
        payloadReplyToId: payload.replyToId,
        fallbackReplyMsgId,
        resolvedReplyMsgId: replyMsgId
    });

    const urls = (payload.mediaUrls || []).filter(url => !!url);
    if (payload.mediaUrl) {
        urls.push(payload.mediaUrl)
    }

    // Send a text message for the clean text
    if (cleanText) {
        await sendTextMessage(to, cleanText, chatType, gid, replyMsgId);
    }

    // Send a message for each media URL
    for (const url of urls) {
        try {
            const fileType = await getFileType(url);
            if (fileType[0] === "img") {
                await sendImageMessage(to, url, fileType[1], chatType, gid, replyMsgId);
            } else if (fileType[0] === "video") {
                await sendVideoMessage(to, url, fileType[1], chatType, gid, replyMsgId);
            } else {
                await sendFileMessage(to, url, fileType[1], chatType, gid, replyMsgId);
            }
        } catch (error) {
            console.error("[LoopChannel] Failed to process media URL:", url, error);
            // 单个媒体处理失败不影响其他媒体的处理
        }
    }
}

async function sendTextMessage(xid: string, text: string, chatType: ChatType = ChatType.DM, gid?: string, replyMsgId?: string) {
    await _sendMessageByAPI({
        "chat_type": chatType,
        "xid": `${xid}`,
        "gid": gid,
        "type": "text",
        "msg": text,
        ...withReplyMsgId(replyMsgId)
    });
}

async function sendImageMessage(xid: string, imageUrl: string, extension: string, chatType: ChatType = ChatType.DM, gid?: string, replyMsgId?: string) {
    // Get image info
    const imageInfo = await getLocalFileInfo(imageUrl);

    if (isLocalFilePath(imageUrl) && localFileExists(imageUrl)) {
        imageUrl = await uploadMediaUrlToOss(token, imageUrl);
    }
    
    await _sendMessageByAPI({
        "chat_type": chatType,
        "xid": `${xid}`,
        "type": "img",
        "gid": gid,
        ...withReplyMsgId(replyMsgId),
        "img": {
            url: imageUrl,
            width: 100,
            height: 100,
            size: imageInfo.size,
            type: extension
        }
    });
}

async function sendVideoMessage(xid: string, videoUrl: string, extension: string, chatType: ChatType = ChatType.DM, gid?: string, replyMsgId?: string) {
    // Get video info
    const videoInfo = await getLocalFileInfo(videoUrl);
    if (isLocalFilePath(videoUrl) && localFileExists(videoUrl)) {
        videoUrl = await uploadMediaUrlToOss(token, videoUrl);
    }
    await _sendMessageByAPI({
        "chat_type": chatType,
        "xid": `${xid}`,
        "type": "video",
        "gid": gid,
        ...withReplyMsgId(replyMsgId),
        "video": {
            url: videoUrl,
            size: videoInfo.size,
            type: extension
        }
    });
}

async function sendFileMessage(xid: string, fileUrl: string, extension: string, chatType: ChatType = ChatType.DM, gid?: string, replyMsgId?: string) {
    // Get file info
    const fileName = fileUrl.split('/').pop() || "";
    const fileInfo = await getLocalFileInfo(fileUrl);
    if (isLocalFilePath(fileUrl) && localFileExists(fileUrl)) {
        fileUrl = await uploadMediaUrlToOss(token, fileUrl);
    }

    // gid
    await _sendMessageByAPI({
        "chat_type": chatType,
        "xid": `${xid}`,
        "type": "file",
        "gid": gid,
        ...withReplyMsgId(replyMsgId),
        "file": {
            url: fileUrl,
            name: fileName,
            size: fileInfo.size,
            type: extension
        }
    });
}

async function _sendMessageByAPI(requestBody: LoopSendRequestBody) {
    if (requestBody.msg?.trim().toLowerCase() == 'terminated') {
        console.log("[LoopChannel] Terminated message, skip sending:", requestBody);
        return
    }

    console.log("[LoopChannel] Sending Loop API request:", requestBody);
    
    const maxRetries = 3;
    let retries = 0;
    
    while (retries <= maxRetries) {
        try {
            const res = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer your-token',
                    'token': token
                },
                body: JSON.stringify(requestBody)
            });
            
            const responseData = await res.json();
            
            if (res.ok) {
                return;
            }
            
            console.error("[LoopChannel] API request failed:", {
                status: res.status,
                statusText: res.statusText,
                data: responseData,
                retry: retries + 1
            });
            
        } catch (error) {
            console.error("[LoopChannel] Network error sending message:", error, requestBody);
        }
        
        retries++;
        if (retries <= maxRetries) {
            const delay = Math.pow(2, retries) * 1000; // 指数退避
            console.log(`[LoopChannel] Retrying in ${delay}ms... (${retries}/${maxRetries})`);
            await new Promise(resolve => setTimeout(resolve, delay));
        }
    }
    
    console.error("[LoopChannel] Failed to send message after all retries:", requestBody);
}
