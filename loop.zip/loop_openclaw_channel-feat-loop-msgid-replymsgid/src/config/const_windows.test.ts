export const hostname = 'api-test.loopspace.xyz'
export const workspaceDir = 'C:\\Users\\Administrator\\.openclaw\\workspace'
export const tokenPath = 'C:\\Users\\Administrator\\.openclaw\\workspace\\token'
