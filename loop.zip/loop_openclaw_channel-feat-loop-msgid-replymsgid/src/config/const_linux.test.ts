export const hostname = 'api-test.loopspace.xyz'
export const workspaceDir = '/home/admin/.openclaw/workspace'
export const tokenPath = '/home/admin/.openclaw/workspace/token'
