export const hostname = 'api.loopspace.xyz'
export const workspaceDir = '/home/admin/.openclaw/workspace'
export const tokenPath = '/home/admin/.openclaw/workspace/token'
