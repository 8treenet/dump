export const hostname = 'api-test.loopspace.xyz'
export const workspaceDir = '~/.openclaw/workspace'
export const tokenPath = '~/.openclaw/workspace/token'
