import fs from 'node:fs';
import https from 'node:https';
import { hostname } from './const';

// OSS 配置接口
interface OssConfig {
  accessKeyId: string;
  accessKeySecret: string;
  stsToken: string;
  bucket: string;
  endpoint: string;
  region: string;
  expires: number;
}

// 获取 OSS 配置
async function getOssConfig(token: string): Promise<OssConfig> {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: hostname,
      path: '/api/app/oss_token',
      method: 'GET',
      headers: {
        'accept': 'application/json, text/plain, */*',
        'token': token,
      }
    };

    const req = https.request(options, (res) => {
      let data = '';

      res.on('data', (chunk) => {
        data += chunk;
      });

      res.on('end', () => {
        try {
          const result = JSON.parse(data);
          if (result.code === 0 && result.data) {
            // 映射响应字段到代码期望的字段名
            const mappedData: OssConfig = {
              accessKeyId: result.data.access_key_id,
              accessKeySecret: result.data.access_key_secret,
              stsToken: result.data.security_token,
              bucket: result.data.bucket,
              endpoint: result.data.endpoint,
              region: result.data.region,
              expires: result.data.expiration
            };
            resolve(mappedData);
          } else {
            reject(new Error(`Failed to get OSS config: ${result.msg || 'Unknown error'}`));
          }
        } catch (error) {
          reject(new Error(`Failed to parse OSS config response: ${error}`));
        }
      });
    });

    req.on('error', (error) => {
      reject(new Error(`Request failed: ${error}`));
    });

    req.end();
  });
}

// 计算签名
function computeSignature(accessKeySecret: string, stringToSign: string): string {
  const crypto = require('crypto');
  return crypto.createHmac('sha1', accessKeySecret).update(stringToSign).digest('base64');
}

// 上传文件到 OSS
async function uploadFileToOss(token: string, localFilePath: string, ossObjectName: string): Promise<string> {
  try {
    // 获取 OSS 配置
    const config = await getOssConfig(token);

    // 读取本地文件
    const fileContent = fs.readFileSync(localFilePath);
    const contentLength = fileContent.length;
    const contentType = 'application/octet-stream';

    // 准备上传参数
    const date = new Date().toUTCString();
    const resource = `/${config.bucket}/${ossObjectName}`;
    
    // 构建签名字符串
    // 包含 x-oss-security-token 头部，因为阿里云 OSS 签名需要包含所有以 x-oss- 开头的头部
    const stringToSign = `PUT\n\n${contentType}\n${date}\nx-oss-security-token:${config.stsToken}\n${resource}`;
    const signature = computeSignature(config.accessKeySecret, stringToSign);

    // 构建 authorization header
    const authorization = `OSS ${config.accessKeyId}:${signature}`;

    // 构建 OSS 上传 URL
    // 移除 endpoint 中的 https:// 前缀，然后构建正确的 URL
    const cleanEndpoint = config.endpoint.replace(/^https?:\/\//, '');
    const ossUrl = `https://${config.bucket}.${cleanEndpoint}${ossObjectName}`;
    const urlParts = new URL(ossUrl);

    // 准备 HTTP 请求选项
    const options = {
      hostname: urlParts.hostname,
      path: urlParts.pathname,
      method: 'PUT',
      headers: {
        'Content-Type': contentType,
        'Content-Length': contentLength,
        'Date': date,
        'Authorization': authorization,
        'x-oss-security-token': config.stsToken
      }
    };

    // 执行上传
    return new Promise((resolve, reject) => {
      const req = https.request(options, (res) => {
        let responseData = '';

        res.on('data', (chunk) => {
          responseData += chunk;
        });

        res.on('end', () => {
          if (res.statusCode === 200) {
            console.log('File uploaded successfully');
            resolve(ossUrl);
          } else {
            reject(new Error(`Upload failed with status code: ${res.statusCode}, response: ${responseData}`));
          }
        });
      });

      req.on('error', (error) => {
        reject(new Error(`Upload request failed: ${error}`));
      });

      // 发送文件内容
      req.write(fileContent);
      req.end();
    });
  } catch (error) {
    console.error('Upload error:', error);
    throw error;
  }
}

// 导出函数
export { getOssConfig, uploadFileToOss };
