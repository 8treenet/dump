import fs from "node:fs";
import path from "node:path";
import { uploadFileToOss } from "./alioss";
import { hostname, workspaceDir, tokenPath } from "./const";


/**
 * Get local file info (size, width, height for images)
 * @param filePath Local file path or URL
 * @returns File info object
 */
export async function getLocalFileInfo(filePath: string): Promise<{ size: number }> {
  // Check if it's an HTTPS URL
  if (filePath.startsWith('https://')) {
    // For HTTPS URLs, return default info
    return { size: 0 };
  }

  // Check if it's a local file path
  if (isLocalFilePath(filePath) && localFileExists(filePath)) {
    try {
      // Get file size
      const stats = fs.statSync(filePath);
      const size = stats.size;

      // For images, we could add width/height detection here
      // For now, return 0 for width/height
      return {
        size: size
      };
    } catch (error) {
      console.error(`[loop-tools] Error getting local file info:`, error);
      return { size: 0 };
    }
  } else {
    // For other URLs or non-existent files, return default info
    return { size: 0 };
  }
}

/**
 * 下载文件到本地临时目录
 * @param url 文件URL
 * @returns 本地文件路径，失败返回 null
 */
export async function downloadFile(url: string): Promise<string | null> {
  try {
    // 创建临时目录，参考其他插件的做法
    const tempDir = path.join(workspaceDir, "loop_media");

    // 确保目录存在
    if (!fs.existsSync(tempDir)) {
      fs.mkdirSync(tempDir, { recursive: true });
    }

    // 下载文件
    const response = await fetch(url);
    if (!response.ok) {
      console.error(`[loop-tools] Download failed: ${response.status} ${response.statusText}`);
      return null;
    }

    const buffer = Buffer.from(await response.arrayBuffer());

    // 确定文件名
    let fileName: string;
    const urlParts = url.split("/");
    const lastPart = urlParts[urlParts.length - 1];

    if (lastPart && lastPart.includes(".")) {
      // 从URL中提取文件名
      const timestamp = Date.now();
      const ext = path.extname(lastPart);
      const baseName = path.basename(lastPart, ext);
      fileName = `${baseName}_${timestamp}${ext}`;
    } else {
      // 生成随机文件名
      const timestamp = Date.now();
      fileName = `download_${timestamp}.bin`;
    }

    const filePath = path.join(tempDir, fileName);

    // 保存文件
    fs.writeFileSync(filePath, buffer);
    console.log(`[loop-tools] Downloaded file: ${filePath}`);

    return filePath;
  } catch (err) {
    console.error(`[loop-tools] Download error:`, err);
    return null;
  }
}

export function getLoopApiUrl(): string {
  const url = `https://${hostname}/api/openclaw/send`;
  return url;
}

// Helper function to check if a path is a local file path
export function isLocalFilePath(filePath: string): boolean {
  // Check if it starts with / or ./ or ~
  if (filePath.startsWith('/') || filePath.startsWith('./') || filePath.startsWith('~/')) {
    return true;
  }

  // Check if it's a relative path without protocol
  if (!filePath.includes('://') && !filePath.startsWith('http')) {
    return true;
  }

  return false;
}

// Helper function to check if a local file exists
export function localFileExists(filePath: string): boolean {
  try {
    // Handle ~ expansion
    const expandedPath = filePath.startsWith('~') ? path.join(process.env.HOME || '', filePath.slice(1)) : filePath;
    return fs.existsSync(expandedPath);
  } catch {
    return false;
  }
}

// Helper function to extract filename from URL
export function getFileNameFromUrl(url: string): string {
  try {
    const urlParts = url.split('/');
    const fileName = urlParts[urlParts.length - 1];
    return fileName || 'file';
  } catch {
    return 'file';
  }
}

// Helper function to upload media URL to OSS
export async function uploadMediaUrlToOss(token: string, filePath: string): Promise<string> {
  try {
    // Check if it's a local file path and if the file exists
    if (!isLocalFilePath(filePath)) {
      return "";
    }

    if (!localFileExists(filePath)) {
      return "";
    }

    const ossObjectName = `loop_openclaw_${Math.random().toString(36).substring(2, 6)}_${Date.now()}/${getFileNameFromUrl(filePath)}`;
    const ossUrl = await uploadFileToOss(token, filePath, ossObjectName);
    return ossUrl;
  } catch (error) {
    console.error(`[LoopChannel] Failed to upload media to OSS: ${filePath}`, error);
    return "";
  }
}

export function getLoopToken(): string {
  const path = tokenPath;
  let token = '';
  try {
    token = fs.readFileSync(path, 'utf-8').trim();
  } catch (error) {
    console.error(`[LoopChannel] Token file not found at ${path}, using default token`);
  }
  return token;
}

// check image/video/file type
export async function getFileType(url: string) {
  const urlParts = url.split('.');
  const extension = urlParts[urlParts.length - 1]?.toLowerCase();
  if (['jpg', 'jpeg', 'png', 'gif', 'webp'].includes(extension)) {
    return ["img", extension];
  }
  if (['mp4', 'avi', 'mov', 'wmv', 'flv', 'mkv'].includes(extension)) {
    return ["video", extension];
  }
  return ["file", extension];
}

export enum ChatType {
  DM = "direct",
  GROUP = "group",
}

export function checkChatType(to: string): ChatType {
  if (to.startsWith(ChatType.DM + ":")) {
    return ChatType.DM;
  }
  if (to.startsWith(ChatType.GROUP + ":")) {
    return ChatType.GROUP;
  }
  return ChatType.DM;
}

//to: dm:${body.from}_${body.to}, 提取发送者 ${body.from}
export function resolveSender(to: string): string {
  const from_to = to.replace(ChatType.DM + ":", "").split("_");
  return from_to[0];
}

// `${ChatType.GROUP}:${gid}_${from}`
export function resovlveGroupSender(to: string):[gid: string, sender: string] {
  const from_to = to.replace(ChatType.GROUP + ":", "").split("_");
  return [from_to[0], from_to[1]];
}

export function buildSender(from: string, to: string, chatType: ChatType = ChatType.DM, gid?: string) {
  switch (chatType) {
    case ChatType.DM:
      return `${ChatType.DM}:${from}_${to}`;
    case ChatType.GROUP:
      return `${ChatType.GROUP}:${gid}_${from}`;
    default:
      return `${ChatType.DM}:${from}_${to}`;
  }
}
