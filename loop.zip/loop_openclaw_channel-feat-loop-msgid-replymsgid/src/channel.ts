import type { ChannelOutboundContext, ChannelPlugin } from "openclaw/plugin-sdk";
import { sendLoopMessage } from "./loopmsg.ts";
import { ChatType, resolveSender, checkChatType, resovlveGroupSender } from "./tools.ts";

export const DEFAULT_ACCOUNT_ID = "loop_default";

export const loopChannel: ChannelPlugin = {
  id: "loop",
  meta: {
    id: "loop",
    label: "Loop Channel",
    selectionLabel: "Loop Channel (API)",
    docsPath: "/channels/loop",
    blurb: "Loop channel plugin with webhook support.",
    aliases: ["loop"],
  },
  capabilities: { chatTypes: ["direct", "group"] },
  status: {
    defaultRuntime: {
      accountId: DEFAULT_ACCOUNT_ID,
      running: false,
      lastStartAt: null,
      lastStopAt: null,
      lastError: null,
    },
    collectStatusIssues: () => [],
    buildChannelSummary: ({ snapshot }) => ({
      configured: snapshot.configured ?? false,
      running: snapshot.running ?? false,
      lastStartAt: snapshot.lastStartAt ?? null,
      lastStopAt: snapshot.lastStopAt ?? null,
      lastError: snapshot.lastError ?? null,
    }),
    probeAccount: async () => ({ ok: true }),
    buildAccountSnapshot: ({ account, runtime }) => ({
      accountId: account.accountId,
      name: account.name || "Loop Channel",
      enabled: account.enabled,
      configured: account.configured,
      running: runtime?.running ?? false,
      lastStartAt: runtime?.lastStartAt ?? null,
      lastStopAt: runtime?.lastStopAt ?? null,
      lastError: runtime?.lastError ?? null,
      mode: runtime?.mode ?? "webhook",
    }),
  },
  config: {
    listAccountIds: (cfg: any) => [DEFAULT_ACCOUNT_ID],
    resolveAccount: (cfg: any, accountId: string | null | undefined) => ({
      accountId: DEFAULT_ACCOUNT_ID,
      enabled: true,
      configured: true,
    }),
    isEnabled: (account: any) => true,
    isConfigured: (account: any) => true,
  },
  gateway: {
    startAccount: async (ctx) => {
      const { accountId, setStatus, abortSignal } = ctx;
      const now = Date.now();
      
      console.log("####### loopdebug ######## startAccount called, accountId:", accountId);
      
      setStatus({
        accountId,
        running: true,
        connected: true,
        enabled: true,
        configured: true,
        lastStartAt: now,
        lastEventAt: now,
        mode: "webhook"
      });
      
      console.log("####### loopdebug ######## Initial status set successfully");

      // 定期更新状态，保持插件活跃
      const intervalId = setInterval(() => {
        const updateTime = Date.now();
        console.log("####### loopdebug ######## Updating status, lastEventAt:", new Date(updateTime).toISOString());
        
        setStatus({
          accountId,
          running: true,
          connected: true,
          lastEventAt: updateTime
        });
      }, 30000); // 每30秒更新一次

      // 返回一个永不resolve的Promise，保持通道运行状态
      return new Promise<void>((resolve) => {
        console.log("####### loopdebug ######## startAccount returned promise, channel is running");
        
        // 监听中止信号
        abortSignal?.addEventListener('abort', () => {
          console.log("####### loopdebug ######## Abort signal received, cleaning up...");
          clearInterval(intervalId);
          setStatus({
            accountId,
            running: false,
            connected: false,
            lastStopAt: Date.now()
          });
          console.log("####### loopdebug ######## Abort signal handled, status set to stopped");
          resolve(); // 通道停止时resolve Promise
        });
      });
    },
    stopAccount: async ({ accountId, setStatus }) => {
      console.log("####### loopdebug ######## stopAccount called, accountId:", accountId);
      
      setStatus({
        accountId,
        running: false,
        connected: false,
        lastStopAt: Date.now()
      });
      
      console.log("####### loopdebug ######## stopAccount completed, status set to stopped");
    }
  },
  messaging: {
    targetResolver: {
      looksLikeId: (input: string) => {
        // Allow any string as a valid target for Loop Channel
        // Including formats like "loop:842921609"
        return true;
      },
    },
  },
  outbound: {
    deliveryMode: "direct",
    sendText: async (ctx: ChannelOutboundContext) => {
      console.log("outbound sendText", ctx);

      const chatType = checkChatType(ctx.to || "");
      
      let to, gid: string | undefined;
      if (chatType === ChatType.GROUP) {
        [gid, to] = resovlveGroupSender(ctx.to || "");
        console.log(`[LoopChannel] sendText gid: ${gid}, to: ${to}`);
      } else {
        to = resolveSender(ctx.to || "");
      }

      await sendLoopMessage({ text: ctx.text, mediaUrls: [ctx.mediaUrl || ""] }, to, chatType, gid);
      return {
        channel: "loop",
        messageId: `msg-${Date.now()}`,
      };
    },
    sendMedia: async (ctx: ChannelOutboundContext) => {
      console.log("sendMedia ctx", ctx);
      const chatType = checkChatType(ctx.to || "");

      let to, gid: string | undefined;
      if (chatType === ChatType.GROUP) {
        [gid, to] = resovlveGroupSender(ctx.to || "");
      } else {
        to = resolveSender(ctx.to || "");
      }
      await sendLoopMessage({ text: ctx.text || "", mediaUrl: ctx.mediaUrl || "" }, to, chatType, gid);
      return {
        channel: "loop",
        messageId: `msg-${Date.now()}`,
      };
    },
  },
};