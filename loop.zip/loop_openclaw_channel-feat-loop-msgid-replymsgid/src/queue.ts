import type { OpenClawPluginApi } from "openclaw/plugin-sdk";
import { ChatType } from "./tools.ts";

// Webhook配置
const LOOP_DEBOUNCE_MS = 100; // 去抖动时间
const LOOP_TEXT_FRAGMENT_MAX_GAP_MS = 1500; // 文本片段合并超时
const LOOP_TEXT_FRAGMENT_MAX_PARTS = 12; // 最大文本片段数
const LOOP_TEXT_FRAGMENT_MAX_TOTAL_CHARS = 50_000; // 最大总字符数

// 消息队列类型定义
export interface MessageQueueItem {
  body: {
    id?: string;
    msgId?: string;
    from: string;
    text: string;
    accountId: string;
    to: string;
    mediaUrl?: string;
    mediaType?: string;
    chatType?: ChatType;
    gid?: string;
  };
  api: OpenClawPluginApi;
  receivedAtMs: number;
}

// 去抖动条目类型
interface DebounceEntry {
  body: MessageQueueItem["body"];
  api: OpenClawPluginApi;
  receivedAtMs: number;
  timer?: NodeJS.Timeout;
}

// 文本片段条目类型
interface TextFragmentEntry {
  key: string;
  messages: Array<{
    body: MessageQueueItem["body"];
    api: OpenClawPluginApi;
    receivedAtMs: number;
  }>;
  timer: NodeJS.Timeout;
}

// 会话隔离的消息队列
export class SessionIsolatedQueue {
  private queues: Map<string, MessageQueueItem[]> = new Map();
  private processing: Map<string, boolean> = new Map();
  private debounceBuffer: Map<string, DebounceEntry> = new Map();
  private textFragmentBuffer: Map<string, TextFragmentEntry> = new Map();
  private processMessageFunc: (body: MessageQueueItem["body"], api: OpenClawPluginApi) => Promise<void>;

  constructor(processMessageFunc: (body: MessageQueueItem["body"], api: OpenClawPluginApi) => Promise<void>) {
    this.processMessageFunc = processMessageFunc;
  }

  // 获取会话键
  private getSessionKey(body: MessageQueueItem["body"]): string {
    const chatType = body.chatType || ChatType.DM;
    return chatType === ChatType.DM 
      ? `loop:${body.accountId}:${body.from}` 
      : `loop:${body.accountId}:group:${body.gid || body.to}`;
  }

  // 去抖动处理
  private handleDebounce(entry: DebounceEntry): void {
    const key = this.getSessionKey(entry.body);
    const existing = this.debounceBuffer.get(key);

    if (existing) {
      clearTimeout(existing.timer);
    }

    const timer = setTimeout(async () => {
      this.debounceBuffer.delete(key);
      await this.enqueueInternal({
        ...entry,
        body: entry.body,
      } as MessageQueueItem);
    }, LOOP_DEBOUNCE_MS);

    this.debounceBuffer.set(key, {
      ...entry,
      timer,
    });
  }

  // 文本片段处理
  private handleTextFragment(item: MessageQueueItem): boolean {
    const { body } = item;
    const text = body.text || "";
    const isCommandLike = text.trim().startsWith("/");

    if (!text || isCommandLike) {
      return false;
    }

    const key = this.getSessionKey(body);
    const existing = this.textFragmentBuffer.get(key);

    if (existing) {
      const last = existing.messages.at(-1);
      const lastReceivedAtMs = last?.receivedAtMs ?? item.receivedAtMs;
      const timeGapMs = item.receivedAtMs - lastReceivedAtMs;

      const canAppend = timeGapMs >= 0 && timeGapMs <= LOOP_TEXT_FRAGMENT_MAX_GAP_MS;

      if (canAppend) {
        const currentTotalChars = existing.messages.reduce(
          (sum, m) => sum + (m.body.text?.length ?? 0),
          0
        );
        const nextTotalChars = currentTotalChars + text.length;

        if (
          existing.messages.length + 1 <= LOOP_TEXT_FRAGMENT_MAX_PARTS &&
          nextTotalChars <= LOOP_TEXT_FRAGMENT_MAX_TOTAL_CHARS
        ) {
          existing.messages.push({
            body: { ...body, text: text },
            api: item.api,
            receivedAtMs: item.receivedAtMs,
          });
          this.scheduleTextFragmentFlush(existing);
          return true;
        }
      }

      // 不能追加，先刷新现有条目
      this.flushTextFragment(existing);
    }

    const shouldStart = text.length >= 4000; // 长文本开始合并
    if (shouldStart) {
      const entry: TextFragmentEntry = {
        key,
        messages: [{ body: { ...body, text }, api: item.api, receivedAtMs: item.receivedAtMs }],
        timer: setTimeout(() => {}, LOOP_TEXT_FRAGMENT_MAX_GAP_MS),
      };
      this.textFragmentBuffer.set(key, entry);
      this.scheduleTextFragmentFlush(entry);
      return true;
    }

    return false;
  }

  // 调度文本片段刷新
  private scheduleTextFragmentFlush(entry: TextFragmentEntry): void {
    clearTimeout(entry.timer);
    entry.timer = setTimeout(() => {
      this.flushTextFragment(entry);
    }, LOOP_TEXT_FRAGMENT_MAX_GAP_MS);
  }

  // 刷新文本片段
  private async flushTextFragment(entry: TextFragmentEntry): Promise<void> {
    this.textFragmentBuffer.delete(entry.key);
    
    if (entry.messages.length === 0) {
      return;
    }

    // 合并文本
    const combinedText = entry.messages
      .map((m) => m.body.text || "")
      .filter(Boolean)
      .join("");

    if (!combinedText.trim()) {
      return;
    }

    // 使用第一个消息作为基础，合并文本
    const first = entry.messages[0];
    const mergedBody = {
      ...first.body,
      text: combinedText,
      id: entry.messages.at(-1)?.body.id || first.body.id,
      msgId: entry.messages.at(-1)?.body.msgId || first.body.msgId,
    };

    await this.enqueueInternal({
      body: mergedBody,
      api: first.api,
      receivedAtMs: entry.messages.at(-1)?.receivedAtMs || first.receivedAtMs,
    });
  }

  // 内部入队
  private async enqueueInternal(item: MessageQueueItem): Promise<void> {
    const key = this.getSessionKey(item.body);
    const queue = this.queues.get(key) || [];
    queue.push(item);
    this.queues.set(key, queue);

    if (!this.processing.get(key)) {
      this.processNext(key);
    }
  }

  // 入队
  async enqueue(body: MessageQueueItem["body"], api: OpenClawPluginApi): Promise<void> {
    const receivedAtMs = Date.now();
    const item: MessageQueueItem = { body, api, receivedAtMs };

    // 先尝试文本片段合并
    if (this.handleTextFragment(item)) {
      return;
    }

    // 再尝试去抖动
    this.handleDebounce({ body, api, receivedAtMs });
  }

  // 处理下一个消息
  private async processNext(key: string): Promise<void> {
    const queue = this.queues.get(key) || [];
    
    if (queue.length === 0) {
      this.processing.set(key, false);
      return;
    }

    this.processing.set(key, true);
    const item = queue.shift();

    if (item) {
      try {
        await this.processMessageFunc(item.body, item.api);
      } catch (error) {
        console.error(`[LoopChannel] Error processing message for session ${key}:`, error);
      } finally {
        this.processNext(key);
      }
    }
  }

  // 清理过期条目
  cleanup(): void {
    const now = Date.now();
    
    // 清理过期的去抖动条目
    for (const [key, entry] of this.debounceBuffer.entries()) {
      if (now - entry.receivedAtMs > LOOP_DEBOUNCE_MS * 2) {
        clearTimeout(entry.timer);
        this.debounceBuffer.delete(key);
      }
    }

    // 清理过期的文本片段
    for (const [key, entry] of this.textFragmentBuffer.entries()) {
      if (now - entry.messages[0].receivedAtMs > LOOP_TEXT_FRAGMENT_MAX_GAP_MS * 2) {
        clearTimeout(entry.timer);
        this.textFragmentBuffer.delete(key);
      }
    }
  }
}

// 注意：消息队列实例现在由webhook.ts创建并导出
